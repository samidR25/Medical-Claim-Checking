#!/usr/bin/env python3
"""
Script to enhance the COVIDFACT dataset with automatically generated counter-claims.
This script loads the original dataset, generates counter-claims, and merges them
in the original format.
"""

import json
import logging
import os
from tqdm import tqdm

from src.counter_claim_generation.improved_generator import ImprovedCounterClaimGenerator

# Set up logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("enhance_dataset.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

def load_dataset(input_file, max_samples=None):
    """Load the input dataset from a JSONL file."""
    claims = []
    try:
        with open(input_file, 'r') as f:
            for i, line in enumerate(f):
                if max_samples and i >= max_samples:
                    break
                
                item = json.loads(line)
                claims.append(item)
    except Exception as e:
        logger.error(f"Error loading dataset: {e}")
        return []
    
    logger.info(f"Loaded {len(claims)} claims from {input_file}")
    return claims

def process_batch(generator, batch, min_contradiction_score, num_candidates):
    """Process a batch of claims to generate counter-claims."""
    processed_batch = []
    
    for item in batch:
        claim = item['claim']
        
        # Skip if it's already a refuted claim
        if item.get('label') == "REFUTED":
            processed_batch.append(item)
            continue
            
        try:
            # Generate counter-claims
            counter_claims = generator.generate_counter_claims(
                claim, 
                num_candidates=num_candidates
            )
            
            # If we found counter-claims, create refuted versions
            if counter_claims:
                # Keep the original supported claim
                processed_batch.append(item)
                
                # Add counter-claims as refuted claims
                for cc in counter_claims:
                    refuted_item = item.copy()
                    refuted_item['claim'] = cc['counter_claim']
                    refuted_item['label'] = "REFUTED"
                    refuted_item['generation_info'] = {
                        'strategy': cc.get('strategy'),
                        'original_claim': claim,
                        'contradiction_score': cc.get('contradiction_score'),
                        'modifications': {
                            k: v for k, v in cc.items() 
                            if k not in ['counter_claim', 'strategy', 'contradiction_score']
                        }
                    }
                    processed_batch.append(refuted_item)
            else:
                # If no counter-claims were generated, just keep the original
                processed_batch.append(item)
                
        except Exception as e:
            logger.error(f"Error processing claim '{claim}': {e}")
            # Add original claim to maintain the dataset structure
            processed_batch.append(item)
    
    return processed_batch

def main():
    # Configuration
    input_file = 'data/raw/COVIDFACT_dataset.jsonl'
    output_file = 'data/processed/enhanced_counter_claims.jsonl'
    batch_size = 10
    min_contradiction_score = 0.7
    num_candidates = 3
    max_samples = None  # Set to None to process entire dataset
    
    # Strategy configuration
    use_strategies = {
        'use_srl': True,
        'use_entity_sub': True,
        'use_quantity_mod': True,
        'use_span_replacement': True,
        'use_dependency_structure': True,
        'contradiction_threshold': min_contradiction_score
    }
    
    # Create output directory if it doesn't exist
    os.makedirs(os.path.dirname(output_file), exist_ok=True)
    
    # Initialize the generator
    logger.info(f"Initializing generator with strategies: {use_strategies}")
    generator = ImprovedCounterClaimGenerator(**use_strategies)
    
    # Load dataset
    dataset = load_dataset(input_file, max_samples)
    
    if not dataset:
        logger.error("No data loaded. Exiting.")
        return
    
    # Process in batches
    results = []
    
    # Create batches
    batches = [dataset[i:i + batch_size] for i in range(0, len(dataset), batch_size)]
    
    logger.info(f"Processing {len(batches)} batches with batch size {batch_size}")
    
    # Display progress bar during processing
    for batch in tqdm(batches, desc="Processing batches"):
        batch_results = process_batch(
            generator, 
            batch, 
            min_contradiction_score, 
            num_candidates
        )
        results.extend(batch_results)
    
    # Save results in JSONL format
    try:
        with open(output_file, 'w') as f:
            for item in results:
                f.write(json.dumps(item) + '\n')
        logger.info(f"Results saved to {output_file}")
    except Exception as e:
        logger.error(f"Error saving results: {e}")
    
    # Log basic stats
    original_claims = len(dataset)
    total_claims = len(results)
    generated_claims = total_claims - original_claims
    supported_claims = sum(1 for r in results if r.get('label') == "SUPPORTED")
    refuted_claims = sum(1 for r in results if r.get('label') == "REFUTED")
    
    logger.info(f"Original claims: {original_claims}")
    logger.info(f"Total claims after enhancement: {total_claims}")
    logger.info(f"Generated counter claims: {generated_claims}")
    logger.info(f"Supported claims: {supported_claims}")
    logger.info(f"Refuted claims: {refuted_claims}")

if __name__ == "__main__":
    main()