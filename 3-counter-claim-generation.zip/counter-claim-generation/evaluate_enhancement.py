#!/usr/bin/env python3
"""
Simplified evaluation script for COVID-Fact dataset enhancement.
Generates basic comparative analysis between original and enhanced datasets.
"""

import json
import logging
import os
import numpy as np
import pandas as pd
from collections import Counter, defaultdict
import matplotlib.pyplot as plt
import seaborn as sns

# Set up logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("evaluate.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

def load_jsonl_data(file_path):
    """Load data from JSONL file (one JSON object per line)"""
    data = []
    try:
        with open(file_path, 'r') as f:
            for line in f:
                try:
                    item = json.loads(line.strip())
                    data.append(item)
                except json.JSONDecodeError:
                    continue
        logger.info(f"Loaded {len(data)} items from {file_path}")
        return data
    except Exception as e:
        logger.error(f"Error loading data: {e}")
        return None

def extract_data_for_analysis(data):
    """Extract key information from the dataset for analysis"""
    extracted = []
    
    for item in data:
        entry = {
            'claim': item.get('claim', ''),
            'label': item.get('label', 'UNKNOWN'),
            'is_generated': 'generation_info' in item,
            'strategy': item.get('generation_info', {}).get('strategy', 'ORIGINAL'),
            'contradiction_score': item.get('generation_info', {}).get('contradiction_score', 0.0),
            'original_claim': item.get('generation_info', {}).get('original_claim', ''),
        }
        
        # Extract modification details if available
        mods = item.get('generation_info', {}).get('modifications', {})
        for k, v in mods.items():
            entry[f'mod_{k}'] = v
        
        extracted.append(entry)
    
    return pd.DataFrame(extracted)

def calculate_sentiment_changes(df):
    """Calculate sentiment changes between original and counter claims"""
    from textblob import TextBlob
    
    results = []
    
    for _, row in df[df['is_generated']].iterrows():
        if not row['original_claim']:
            continue
        
        original_sentiment = TextBlob(row['original_claim']).sentiment.polarity
        counter_sentiment = TextBlob(row['claim']).sentiment.polarity
        
        results.append({
            'strategy': row['strategy'],
            'original_sentiment': original_sentiment,
            'counter_sentiment': counter_sentiment,
            'sentiment_shift': counter_sentiment - original_sentiment
        })
    
    return pd.DataFrame(results)

def analyze_dataset_stats(enhanced_df, original_df=None):
    """Calculate detailed dataset statistics"""
    stats = {}
    
    # Enhanced dataset statistics
    stats['enhanced'] = {
        'total_claims': len(enhanced_df),
        'original_claims': len(enhanced_df[~enhanced_df['is_generated']]),
        'generated_claims': len(enhanced_df[enhanced_df['is_generated']]),
        'supported_claims': len(enhanced_df[enhanced_df['label'] == 'SUPPORTED']),
        'refuted_claims': len(enhanced_df[enhanced_df['label'] == 'REFUTED']),
    }
    
    # Strategy distribution
    strategy_counts = enhanced_df[enhanced_df['is_generated']]['strategy'].value_counts().to_dict()
    stats['strategies'] = strategy_counts
    
    # Calculate average word overlap
    if 'original_claim' in enhanced_df.columns:
        import re
        overlaps = []
        for _, row in enhanced_df[enhanced_df['is_generated']].iterrows():
            if row['original_claim']:
                original_words = set(re.findall(r'\b\w+\b', row['original_claim'].lower()))
                counter_words = set(re.findall(r'\b\w+\b', row['claim'].lower()))
                
                if not original_words:
                    continue
                
                overlap = len(original_words.intersection(counter_words))
                overlaps.append(overlap / len(original_words))
        
        if overlaps:
            stats['word_overlap'] = {
                'mean': np.mean(overlaps),
                'median': np.median(overlaps),
                'min': np.min(overlaps),
                'max': np.max(overlaps)
            }
    
    # Contradiction score statistics
    if 'contradiction_score' in enhanced_df.columns:
        contradiction_scores = enhanced_df[enhanced_df['is_generated']]['contradiction_score'].dropna()
        if not contradiction_scores.empty:
            stats['contradiction_scores'] = {
                'mean': contradiction_scores.mean(),
                'median': contradiction_scores.median(),
                'min': contradiction_scores.min(),
                'max': contradiction_scores.max()
            }
    
    # Comparison with original dataset if available
    if original_df is not None:
        stats['original'] = {
            'total_claims': len(original_df),
            'supported_claims': len(original_df[original_df['label'] == 'SUPPORTED']),
            'refuted_claims': len(original_df[original_df['label'] == 'REFUTED']),
        }
        
        # Calculate expansion ratio
        stats['expansion_ratio'] = len(enhanced_df) / len(original_df)
        
    return stats

def create_strategy_analysis_charts(enhanced_df, output_dir, stats):
    """Create strategy analysis visualizations"""
    plt.style.use('ggplot')
    
    plt.figure(figsize=(10, 6))
    
    # Calculate and plot average contradiction scores by strategy
    strategies = []
    scores = []
    
    for strategy in enhanced_df[enhanced_df['is_generated']]['strategy'].unique():
        strategy_scores = enhanced_df[(enhanced_df['is_generated']) & 
                                    (enhanced_df['strategy'] == strategy)]['contradiction_score'].dropna()
        if not strategy_scores.empty:
            strategies.append(strategy)
            scores.append(strategy_scores.mean())
    
    bars = plt.bar(strategies, scores, color=plt.cm.tab10(range(len(strategies))))
    
    # Add value labels
    for bar in bars:
        height = bar.get_height()
        plt.text(bar.get_x() + bar.get_width()/2., height + 0.01,
                f'{height:.2f}', ha='center', va='bottom')
    
    plt.title('Average Contradiction Score by Strategy', fontsize=14)
    plt.xticks(rotation=45, ha='right')
    plt.ylim(0, 1.1)
    
    plt.tight_layout()
    plt.savefig(os.path.join(output_dir, 'strategy_analysis.png'), dpi=300)
    plt.close()

def create_sentiment_analysis_chart(enhanced_df, output_dir):
    """Create sentiment analysis visualization"""
    sentiment_df = calculate_sentiment_changes(enhanced_df)
    
    if not sentiment_df.empty:
        plt.figure(figsize=(12, 10))
        
        # Sentiment change distribution
        plt.subplot(2, 1, 1)
        sns.histplot(sentiment_df['sentiment_shift'], kde=True)
        plt.title('Distribution of Sentiment Shifts', fontsize=14)
        plt.xlabel('Sentiment Shift (Negative = More Negative)')
        plt.ylabel('Frequency')
        
        # Average sentiment shift by strategy
        plt.subplot(2, 1, 2)
        sentiment_by_strategy = sentiment_df.groupby('strategy')['sentiment_shift'].mean().sort_values()
        
        bars = plt.bar(sentiment_by_strategy.index, sentiment_by_strategy.values, 
                     color=plt.cm.RdBu(np.linspace(0, 1, len(sentiment_by_strategy))))
        
        # Add value labels
        for bar in bars:
            height = bar.get_height()
            color = 'black'
            plt.text(bar.get_x() + bar.get_width()/2., 
                    height + 0.02 if height >= 0 else height - 0.08,
                    f'{height:.2f}', ha='center', va='bottom', color=color)
        
        plt.title('Average Sentiment Shift by Strategy', fontsize=14)
        plt.xticks(rotation=45, ha='right')
        plt.axhline(y=0, color='k', linestyle='-', alpha=0.3)
        
        plt.tight_layout()
        plt.savefig(os.path.join(output_dir, 'sentiment_analysis.png'), dpi=300)
        plt.close()

def main():
    """Main evaluation function"""
    # Fixed configuration - no command line args
    input_file = 'data/processed/enhanced_full_dataset.jsonl'
    output_dir = 'data/evaluation/'
    original_file = 'data/raw/COVIDFACT_dataset.jsonl'
    
    # Create output directory
    os.makedirs(output_dir, exist_ok=True)
    
    # Load enhanced dataset
    logger.info(f"Loading enhanced dataset from {input_file}")
    enhanced_data = load_jsonl_data(input_file)
    if not enhanced_data:
        logger.error("Failed to load enhanced dataset. Exiting.")
        return
    
    # Load original dataset if provided
    original_data = None
    if original_file:
        logger.info(f"Loading original dataset from {original_file}")
        original_data = load_jsonl_data(original_file)
    
    # Convert to dataframes for analysis
    enhanced_df = extract_data_for_analysis(enhanced_data)
    original_df = extract_data_for_analysis(original_data) if original_data else None
    
    # Run analyses
    logger.info("Analyzing datasets...")
    stats = analyze_dataset_stats(enhanced_df, original_df)
    
    # Create visualizations
    logger.info("Creating visualizations...")
    create_strategy_analysis_charts(enhanced_df, output_dir, stats)
    create_sentiment_analysis_chart(enhanced_df, output_dir)
    
    # Save statistics to JSON
    logger.info("Saving evaluation results...")
    with open(os.path.join(output_dir, 'evaluation_results.json'), 'w') as f:
        json.dump(stats, f, indent=2)
    
    logger.info(f"Results saved to: {output_dir}")
    
    # Print key statistics
    print("\n===== Dataset Enhancement Summary =====")
    print(f"Original claims: {stats['original']['total_claims'] if 'original' in stats else stats['enhanced']['original_claims']}")
    print(f"Generated counter-claims: {stats['enhanced']['generated_claims']}")
    print(f"Total claims after enhancement: {stats['enhanced']['total_claims']}")
    print(f"Supported claims: {stats['enhanced']['supported_claims']}")
    print(f"Refuted claims: {stats['enhanced']['refuted_claims']}")
    print("\nStrategy distribution:")
    for strategy, count in stats.get('strategies', {}).items():
        print(f"  - {strategy}: {count}")

if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        logger.error(f"Evaluation failed: {e}")
        import traceback
        traceback.print_exc()