"""
Improved counter-claim generator with multi-word modification strategies.
This version enhances the original generator to modify groups of words rather than just single tokens.
"""

import spacy
import torch
from transformers import AutoTokenizer, AutoModelForMaskedLM, AutoModelForSequenceClassification
import re
import os
import json
import logging

logger = logging.getLogger(__name__)

class ImprovedCounterClaimGenerator:
    """Enhanced counter-claim generator with group-word modification strategies."""
    
    def __init__(self, 
                use_srl=True, 
                use_entity_sub=True, 
                use_quantity_mod=True, 
                use_negation=True,
                use_span_replacement=True,
                use_dependency_structure=True,
                contradiction_threshold=0.7,
                dictionary_dir="data/dictionaries"):
        """Initialize with desired strategies and models."""
        self.use_srl = use_srl
        self.use_entity_sub = use_entity_sub
        self.use_quantity_mod = use_quantity_mod
        self.use_negation = use_negation
        self.use_span_replacement = use_span_replacement
        self.use_dependency_structure = use_dependency_structure
        self.contradiction_threshold = contradiction_threshold
        self.dictionary_dir = dictionary_dir
        self._load_dictionaries()
        
        # Strategy priority - order matters!
        self.strategy_priority = [
            "span_replacement",
            "dependency_structure",
            "srl",
            "entity_substitution",
            "quantity_modification"
        ]
        
        # Map strategy names to methods
        self.strategy_methods = {
            "span_replacement": self._apply_span_replacement,
            "dependency_structure": self._apply_dependency_structure,
            "srl": self._verb_replacement,
            "entity_substitution": self._entity_substitution,
            "quantity_modification": self._modify_quantities,
        }
        
        # Initialize NLP tools
        self.nlp = spacy.load("en_core_web_sm")
        
        # Load transformer models
        self.tokenizer = AutoTokenizer.from_pretrained("roberta-large")
        
        try:
            self.mlm_model = AutoModelForMaskedLM.from_pretrained("allenai/biomed_roberta_base")
        except:
            self.mlm_model = AutoModelForMaskedLM.from_pretrained("roberta-large")
        
        # Load NLI model for contradiction detection
        self.nli_tokenizer = AutoTokenizer.from_pretrained("roberta-large-mnli")
        self.nli_model = AutoModelForSequenceClassification.from_pretrained("roberta-large-mnli")
        
        # Put models in evaluation mode
        self.mlm_model.eval()
        self.nli_model.eval()
        
        # Use GPU if available
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.mlm_model.to(self.device)
        self.nli_model.to(self.device)
    
    def _load_dictionaries(self):
        """Load dictionaries from files"""
        if not os.path.exists(self.dictionary_dir):
            os.makedirs(self.dictionary_dir, exist_ok=True)
            
        dictionary_files = [
            "entity_replacements.json",
            "phrase_replacements.json",
            "action_replacements.json",
            "preposition_opposites.json"
        ]
        
        for filename in dictionary_files:
            file_path = os.path.join(self.dictionary_dir, filename)
            with open(file_path, 'r') as f:
                attr_name = filename.split('.')[0]
                setattr(self, attr_name, json.load(f))
    
    def generate_counter_claims(self, claim, num_candidates=3):
        """Generate counter-claims for a given claim using various strategies."""
        candidates = []
        
        # Parse the claim with spaCy
        doc = self.nlp(claim)
        
        # Apply strategies in priority order
        for strategy_name in self.strategy_priority:
            strategy_method = self.strategy_methods.get(strategy_name)
            
            # Check if the strategy is enabled
            strategy_enabled = getattr(self, f"use_{strategy_name.lower()}", False)
            
            # Apply the strategy if enabled
            if strategy_enabled and strategy_method:
                strategy_candidates = strategy_method(claim, doc)
                candidates.extend(strategy_candidates)
        
        # Filter candidates by contradiction score
        filtered_candidates = []
        for candidate in candidates:
            if "counter_claim" in candidate:
                if candidate["counter_claim"] == claim:
                    continue
                    
                contradiction_score = self._check_contradiction(claim, candidate["counter_claim"])
                
                if contradiction_score >= self.contradiction_threshold:
                    candidate["contradiction_score"] = contradiction_score
                    filtered_candidates.append(candidate)
        
        # Deduplicate candidates
        unique_candidates = []
        seen_counter_claims = set()
        
        for candidate in filtered_candidates:
            counter_claim = candidate["counter_claim"]
            if counter_claim not in seen_counter_claims:
                seen_counter_claims.add(counter_claim)
                unique_candidates.append(candidate)
        
        # Sort by contradiction score and return top candidates
        unique_candidates.sort(key=lambda x: x.get("contradiction_score", 0), reverse=True)
        return unique_candidates[:num_candidates]
    
    def _apply_span_replacement(self, claim, doc):
        """Generate counter-claims by replacing multi-word phrases"""
        candidates = []
        
        for phrase, replacements in self.phrase_replacements.items():
            if phrase.lower() in claim.lower():
                pattern = re.compile(re.escape(phrase), re.IGNORECASE)
                matches = pattern.finditer(claim)
                
                for match in matches:
                    for replacement in replacements:
                        counter_claim = claim[:match.start()] + replacement + claim[match.end():]
                        
                        candidates.append({
                            "counter_claim": counter_claim,
                            "strategy": "span_replacement",
                            "original_span": phrase,
                            "replacement_span": replacement
                        })
        
        return candidates
    
    def _apply_dependency_structure(self, claim, doc):
        """Generate counter-claims by modifying dependency structures"""
        candidates = []
        
        # Find verb-object pairs
        for token in doc:
            if token.pos_ == "VERB":
                obj_tokens = [child for child in token.children if child.dep_ == "dobj"]
                
                if obj_tokens:
                    for obj in obj_tokens:
                        verb = token.text
                        object_span = obj.text
                        original_pair = f"{verb} {object_span}"
                        
                        if verb.lower() in self.action_replacements:
                            for replacement_verb in self.action_replacements[verb.lower()]:
                                new_pair = f"{replacement_verb} {object_span}"
                                counter_claim = claim.replace(original_pair, new_pair)
                                
                                if counter_claim != claim:
                                    candidates.append({
                                        "counter_claim": counter_claim,
                                        "strategy": "verb_object_replacement",
                                        "original_structure": original_pair,
                                        "replacement_structure": new_pair
                                    })
        
        return candidates
    
    def _entity_substitution(self, claim, doc):
        """Generate counter-claims by substituting entities"""
        candidates = []
        
        # Method 1: Direct matching from entity dictionary
        for original, replacements in self.entity_replacements.items():
            if original.lower() in claim.lower():
                pattern = r'\b' + re.escape(original) + r'\b'
                if not re.search(pattern, claim, re.IGNORECASE):
                    continue
                
                for replacement in replacements:
                    counter_claim = re.sub(pattern, replacement, claim, flags=re.IGNORECASE)
                    
                    candidates.append({
                        "counter_claim": counter_claim,
                        "strategy": "entity_substitution",
                        "original_entity": original,
                        "replacement_entity": replacement
                    })
        
        # Method 2: Find entities using spaCy's NER
        for ent in doc.ents:
            if ent.label_ in ["ORG", "PRODUCT", "GPE", "PERSON", "DISEASE", "CHEMICAL", "WORK_OF_ART"]:
                replacements = []
                
                if ent.text in self.entity_replacements:
                    replacements = self.entity_replacements[ent.text]
                elif ent.label_ == "ORG" and any(term in ent.text.lower() for term in ["cdc", "who", "fda", "nih"]):
                    replacements = ["researchers", "scientists", "doctors", "experts"]
                elif ent.label_ == "PRODUCT" and any(term in ent.text.lower() for term in ["vaccine", "treatment", "drug"]):
                    replacements = ["placebo", "alternative treatment", "untested remedy"]
                elif ent.label_ == "GPE":
                    replacements = ["other countries", "different regions", "most places"]
                elif ent.label_ == "DISEASE" and "covid" not in ent.text.lower():
                    replacements = ["COVID-19", "coronavirus infection"]
                elif ent.label_ == "DISEASE" and "covid" in ent.text.lower():
                    replacements = ["influenza", "common cold", "seasonal flu"]
                
                if replacements:
                    for replacement in replacements:
                        pattern = r'\b' + re.escape(ent.text) + r'\b'
                        counter_claim = re.sub(pattern, replacement, claim)
                        
                        if counter_claim != claim:
                            candidates.append({
                                "counter_claim": counter_claim,
                                "strategy": "entity_replacement",
                                "original_entity": ent.text,
                                "replacement_entity": replacement,
                                "entity_type": ent.label_
                            })
        
        return candidates
    
    def _modify_quantities(self, claim, doc):
        """Generate counter-claims by modifying numerical quantities"""
        candidates = []
        
        # Find numbers
        for token in doc:
            if token.like_num:
                try:
                    original_num = float(token.text)
                    
                    # Skip years
                    if 1900 < original_num < 2100:
                        continue
                    
                    # Modify the number
                    if original_num < 10:
                        new_num = original_num * 10
                    else:
                        new_num = original_num / 2
                    
                    # Format new number
                    new_text = str(int(new_num)) if original_num == int(original_num) else f"{new_num:.1f}"
                    
                    # Create counter-claim
                    counter_claim = claim.replace(token.text, new_text)
                    candidates.append({
                        "counter_claim": counter_claim,
                        "strategy": "quantity_modification",
                        "original_quantity": token.text,
                        "modified_quantity": new_text
                    })
                except ValueError:
                    continue
        
        return candidates
    
    def _verb_replacement(self, claim, doc):
        """Generate counter-claims by replacing key verbs"""
        candidates = []
        
        # Find the main verbs in the claim
        for token in doc:
            if token.pos_ == "VERB":
                # Check if it's in our dictionary of replacements
                if token.lemma_ in self.action_replacements or token.text in self.action_replacements:
                    replacements = self.action_replacements.get(token.lemma_, self.action_replacements.get(token.text, []))
                else:
                    # Try to find replacements via MLM
                    replacements = self._get_mlm_replacements(claim, token)
                
                # Create counter-claims with replacement verbs
                for replacement in replacements:
                    # Make sure we're replacing only the exact verb
                    pattern = r'\b' + re.escape(token.text) + r'\b'
                    counter_claim = re.sub(pattern, replacement, claim)
                    
                    if counter_claim != claim:
                        candidates.append({
                            "counter_claim": counter_claim,
                            "strategy": "verb_replacement",
                            "original_verb": token.text,
                            "replacement_verb": replacement
                        })
        
        return candidates
    
    def _get_mlm_replacements(self, claim, token):
        """Use masked language model to find potential replacements for a token"""
        # Create a masked version of the claim
        masked_claim = claim.replace(token.text, self.tokenizer.mask_token)
        
        # Tokenize
        inputs = self.tokenizer(masked_claim, return_tensors="pt")
        inputs = {k: v.to(self.device) for k, v in inputs.items()}
        
        # Find the position of the mask token
        mask_token_index = torch.where(inputs["input_ids"] == self.tokenizer.mask_token_id)[1]
        
        # Get predictions
        with torch.no_grad():
            outputs = self.mlm_model(**inputs)
            predictions = outputs.logits
        
        # Get top predictions
        predicted_token_ids = torch.topk(predictions[0, mask_token_index], k=10, dim=1).indices[0]
        predicted_tokens = [self.tokenizer.decode(token_id.item()) for token_id in predicted_token_ids]
        
        # Filter predictions
        filtered_tokens = []
        for pred_token in predicted_tokens:
            pred_token = pred_token.strip()
            if (pred_token != token.text and 
                pred_token not in [',', '.', '!', '?', ' ', ''] and
                len(pred_token) > 1):
                filtered_tokens.append(pred_token)
        
        return filtered_tokens[:5]  # Return top 5 filtered predictions
    
    def _check_contradiction(self, original_claim, counter_claim):
        """Check if the counter-claim contradicts the original claim using an NLI model"""
        # Tokenize for the NLI model
        inputs = self.nli_tokenizer(original_claim, counter_claim, return_tensors="pt", padding=True, truncation=True)
        inputs = {k: v.to(self.device) for k, v in inputs.items()}
        
        # Get model prediction
        with torch.no_grad():
            outputs = self.nli_model(**inputs)
            probs = torch.nn.functional.softmax(outputs.logits, dim=1)[0]
        
        # Return the contradiction probability
        contradiction_score = probs[2].item()
        return contradiction_score